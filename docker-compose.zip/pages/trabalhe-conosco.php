
<header class="slider-int">
    <div class="content">
        <h1>Trabalhe Conosco</h1>
    </div>
</header>



<section class="py-5">
<div class="container mt-5">


<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $base = $_POST['base'];
    $mensagem = $_POST['mensagem'];
    $curriculo = $_FILES['curriculo'];
    
    // Definir os e-mails com base na escolha
    $emails = [
        "pinda" => "pinda.vagas@securitymaster.com.br",
        "taubate" => "taubate.vagas@securitymaster.com.br",
        "campos" => "campos.vagas@securitymaster.com.br"
    ];
    
    $para = $emails[$base];
    $assunto = "Novo Currículo - $nome";
    
    // Criar o corpo do e-mail
    $mensagem_email = "Nome: $nome\nEmail: $email\nTelefone: $telefone\nMensagem: $mensagem";
    
    // Configurar cabeçalhos do e-mail
    $boundary = md5(time());
    $headers = "From: $email\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";
    
    // Corpo do e-mail com anexo
    $mensagem_completa = "--$boundary\r\n";
    $mensagem_completa .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
    $mensagem_completa .= "$mensagem_email\r\n";
    
    if ($curriculo['error'] == 0) {
        $conteudo_arquivo = file_get_contents($curriculo['tmp_name']);
        $conteudo_arquivo = chunk_split(base64_encode($conteudo_arquivo));
        $nome_arquivo = $curriculo['name'];
        
        $mensagem_completa .= "--$boundary\r\n";
        $mensagem_completa .= "Content-Type: application/octet-stream; name=\"$nome_arquivo\"\r\n";
        $mensagem_completa .= "Content-Transfer-Encoding: base64\r\n";
        $mensagem_completa .= "Content-Disposition: attachment; filename=\"$nome_arquivo\"\r\n\r\n";
        $mensagem_completa .= "$conteudo_arquivo\r\n";
    }
    
    $mensagem_completa .= "--$boundary--";
    
    // Enviar o e-mail
    if (mail($para, $assunto, $mensagem_completa, $headers)) {
        echo "<div class='alert alert-success'>Currículo enviado com sucesso!</div>";
    } else {
        echo "<div class='alert alert-danger'>Erro ao enviar currículo.</div>";
    }
}
?>

        <form action="" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome Completo</label>
                <input type="text" class="form-control" id="nome" name="nome" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="telefone" class="form-label">Telefone</label>
                <input type="text" class="form-control" id="telefone" name="telefone" required>
            </div>
            <div class="mb-3">
                <label for="base" class="form-label">Selecione a Base</label>
                <select class="form-control" id="base" name="base" required>
                    <option value="pinda">Pindamonhangaba</option>
                    <option value="taubate">Taubaté</option>
                    <option value="campos">Campos do Jordão</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="mensagem" class="form-label">Mensagem</label>
                <textarea class="form-control" id="mensagem" name="mensagem" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="curriculo" class="form-label">Anexe seu Currículo (PDF)</label>
                <input type="file" class="form-control" id="curriculo" name="curriculo" accept=".pdf" required>
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
    </div>
</section>



<?php
include('components/#unidades.php');
?>