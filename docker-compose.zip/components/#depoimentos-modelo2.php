<section class="py-5" style="background-color: #d4a017;">
    <div class="container">
        <h2 class="text-center">Depoimentos</h2>
        <div class="row text-center mt-4">
            <div class="col-md-4">
                <img src="<?php echo "{$url}src/images/avatar.png"; ?>" class="rounded-circle" alt="João Bnedito" style="width: 80px;">
                <h5 class="mt-3">João Bnedito</h5>
                <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</p>
            </div>
            <div class="col-md-4">
                <img src="<?php echo "{$url}src/images/avatar.png"; ?>" class="rounded-circle" alt="Luiza Silva" style="width: 80px;">
                <h5 class="mt-3">Luiza Silva</h5>
                <p>Amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis.</p>
            </div>
            <div class="col-md-4">
                <img src="<?php echo "{$url}src/images/avatar.png"; ?>" class="rounded-circle" alt="Paulo Ernani" style="width: 80px;">
                <h5 class="mt-3">Paulo Ernani</h5>
                <p>Consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor.</p>
            </div>
        </div>
    </div>
</section>