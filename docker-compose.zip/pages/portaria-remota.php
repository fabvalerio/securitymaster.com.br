<header class="slider-int">
    <div class="content">
        <h1>Portaria Remota</h1>
    </div>
</header>

<section class="container my-5 diferenciais-portaria">
    <div class="row align-items-center">
        <div class="col-md-6 image-section">
            <img src="<?php echo "{$url}src/images/img-empresa-taubate.png"; ?>" alt="Security Master" class="img-fluid">
        </div>
        <div class="col-md-6 text-section">
            <p>Com mais de 25 anos de experiência, a Security Master é referência em soluções de segurança e serviços especializados. Nossa missão é proteger o que é mais importante para você, combinando tecnologia de ponta, profissionais qualificados e atendimento personalizado. Atuamos com ética, compromisso e inovação.”</p>
            <h3>Nossos Diferenciais</h3>
            <ul>
                <li>Mais de 25 anos no mercado de segurança.</li>
                <li>Equipamentos modernos e sistemas avançados.</li>
                <li>Profissionais treinados e certificados.</li>
                <li>Atendimento personalizado para cada cliente.</li>
            </ul>
            <a href="#" class="btn btn-warning">Fale com um consultor</a>
        </div>
    </div>
</section>

<section class=" my-5 bg-light">
    <div class="container py-5">
        <h3 class="text-center">Adequação à LGPD</h3>
        <p>A Security Master está totalmente alinhada à Lei Geral de Proteção de Dados (LGPD), garantindo que todos os dados pessoais tratados em suas operações sejam protegidos de acordo com as exigências legais. Implementamos medidas técnicas e administrativas para assegurar a privacidade e a segurança das informações, desde a coleta até o armazenamento e uso. </p>
        <p>Adotamos boas práticas de privacidade e realizamos mapeamento de fluxos de dados, avaliação contínua de riscos e implementação de controles rigorosos para prevenir acessos não autorizados, vazamentos ou qualquer uso inadequado das informações.</p>
        <p>Nosso programa de governança em privacidade inclui políticas claras, treinamento contínuo dos colaboradores e monitoramento constante para garantir conformidade. Também contamos com um plano estruturado para resposta a incidentes, assegurando agilidade na contenção e comunicação em casos de eventuais problemas. </p>
        <p>Com essas ações, reafirmamos nosso compromisso com a transparência e a segurança, garantindo que os dados de nossos clientes estejam sempre protegidos e em conformidade com a LGPD.</p>
    </div>
</section>

<section class="container my-5">
    <div class="row align-items-center">
        <div class="col-md-6 text-section">
            <h3>Como Funciona</h3>
            <p>A Portaria Remota opera com tecnologia avançada para gerenciar o acesso ao condomínio de forma eficiente e segura. Por meio de câmeras de alta resolução e softwares inteligentes, todas as entradas e saídas são monitoradas em tempo real por uma equipe especializada, garantindo total controle e tranquilidade.</p>
            <hr>
            <p><strong>Passo a Passo Simples e Seguro</strong></p>
            <ol>
                <li>Identificação: Visitantes e entregadores são identificados remotamente via interfone ou aplicativo.</li>
                <li>Autorização: A entrada é autorizada pelo morador ou pelo sistema pré-configurado.</li>
                <li>Monitoramento: Toda a operação é registrada, oferecendo transparência e rastreabilidade.</li>
            </ol>
            <p>
                Descubra como a Portaria Remota pode transformar a segurança do seu condomínio.
            </p>
            <a href="#" class="btn btn-warning">Fale com um consultor</a>
        </div>
        <div class="col-md-6 image-section">
            <img src="<?php echo "{$url}src/images/img-portaria.jpg"; ?>" class="img-fluid" alt="Monitoramento">
        </div>
    </div>
</section>

<section class="bg-light">
    <div class="container py-5">
        <h3 class="text-start">Vantagens</h3>
        <div class="row g-5 mt-3">
            <div class="col-md-6">
                <h5>Monitoramento 24/7</h5>
                <p>Segurança contínua com vigilância ininterrupta.</p>
            </div>
            <div class="col-md-6">
                <h5>Economia de Recursos</h5>
                <p>Reduza custos com um modelo mais eficiente.</p>
            </div>
            <div class="col-md-6">
                <h5>Acesso Controlado</h5>
                <p>Gerenciamento preciso de entradas e saídas.</p>
            </div>
            <div class="col-md-6">
                <h5>Solução Personalizada</h5>
                <p>Adaptação total às necessidades do seu condomínio.</p>
            </div>
        </div>
    </div>
</section>

<section class="text-center text-white bg-back py-5">
    <div class="container">
        <h2>Onde pode ser utilizado?</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</p>
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card">
                    <img src="<?php echo "{$url}src/images/img-predios.jpg"; ?>" class="card-img-top" alt="Prédios">
                    <div class="card-body">
                        <h5 class="card-title">Prédios</h5>
                        <p class="card-text">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="<?php echo "{$url}src/images/img-condominios.jpg"; ?>" class="card-img-top" alt="Condomínios">
                    <div class="card-body">
                        <h5 class="card-title">Condomínios</h5>
                        <p class="card-text">Amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="<?php echo "{$url}src/images/img-empresas.jpg"; ?>" class="card-img-top" alt="Empresas">
                    <div class="card-body">
                        <h5 class="card-title">Empresas</h5>
                        <p class="card-text">Consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="container my-5 py-5">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h2>Investimento</h2>
            <p>Adotar a Portaria Remota é mais do que uma escolha por segurança, é uma decisão inteligente para reduzir custos e aumentar a eficiência. Com valores acessíveis e flexíveis, o retorno do investimento é percebido rapidamente, tanto na economia com mão de obra quanto na valorização do imóvel.</p>
            <button class="btn btn-custom">Fale com um consultor</button>
        </div>
        <div class="col-md-6 text-center">
            <img src="<?php echo "{$url}src/images/setas.jpg"; ?>" alt="Investimento" class="img-fluid" style="max-width: 200px;">
        </div>
    </div>
</section>



<?php
include 'components/#depoimentos-modelo2.php';
include 'components/#unidades.php';
include('components/#contato.php');
?>