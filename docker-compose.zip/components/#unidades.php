<section class="diferenca" id="unidades">
    <div class="container">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="col-lg-6 mb-4">
                <h2 class="title">Aqui nós fazemos <br>a diferença!</h2>
            </div>
            <div class="col-lg-6 mb-4">
                <p class="description">
                    O Grupo Security Master é a maior empresa nos segmentos de serviços e segurança nas regiões do Vale do Paraíba e Serra da Mantiqueira, com bases operacionais de atendimento em Campos do Jordão, Pindamonhangaba e Taubaté e também com atuação nas cidades de Guaratinguetá, Aparecida, Santo Antônio do Pinhal, Tremembé, São Bento do Sapucaí e Caçapava.
                </p>
            </div>
        </div>
        <div class="row">
            <!-- Card 1 -->
            <div class="col-md-4">
                <div class="card  shadow-sm">
                    <div class="position-relative">
                        <h6 class="position-absolute bg-warning d-inline p-3 m-0 bottom-0 start-10">Taubaté</h6>
                        <img src="<?php echo "{$url}src/images/uni-tte.jpg";?>" class="card-img-top" alt="Security Master Taubaté">
                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            Avenida Bandeirantes, nº 5100<br>
                            Jardim Independência<br>
                            (12) 3609-5530
                        </p>
                        <a href="#" class="btn btn-outline-dark">Como chegar →</a>
                    </div>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="col-md-4">
                <div class="card  shadow-sm">
                    <div class="position-relative">
                        <h6 class="position-absolute bg-warning d-inline p-3 m-0 bottom-0 start-10">Campos do Jordão</h6>
                        <img src="<?php echo "{$url}src/images/uni-cjo.jpg";?>" class="card-img-top" alt="Security Master Campos do Jordão">
                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            Rua Inácio Caetano, nº 941<br>
                            Vila Suíça<br>
                            (12) 3668-9898 / 3668-9897
                        </p>
                        <a href="#" class="btn btn-outline-dark">Como chegar →</a>
                    </div>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="col-md-4">
                <div class="card  shadow-sm">
                    <div class="position-relative">
                        <h6 class="position-absolute bg-warning d-inline p-3 m-0 bottom-0 start-10">Pindamonhangaba</h6>
                        <img src="<?php echo "{$url}src/images/uni-pinda.jpg";?>" class="card-img-top" alt="Security Master Pindamonhangaba">
                    </div>
                    <div class="card-body">
                        <p class="card-text">
                            Avenida Albuquerque Lins, nº 21<br>
                            Centro<br>
                            (12) 3643-2009 / 3645-4228
                        </p>
                        <a href="#" class="btn btn-outline-dark">Como chegar →</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
