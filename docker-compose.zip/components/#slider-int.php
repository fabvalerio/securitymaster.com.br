<!-- Slider -->
<div class="slider bg-dark">
        <div class="content">
            <h1>HÁ MAIS DE 25 ANOS NO MERCADO</h1>
            <p>Uma história construída com comprometimento, seriedade, responsabilidade e confiança.</p>
            <button class="btn btn-warning">Quem Somos</button>
        </div>
    </div>
