<style>
    /*---------------------------------------------*/
    input {
        outline: none;
        border: none;
    }

    input[type="number"] {
        -moz-appearance: textfield;
        appearance: none;
        -webkit-appearance: none;
    }

    input[type="number"]::-webkit-outer-spin-button,
    input[type="number"]::-webkit-inner-spin-button {
        -webkit-appearance: none;
    }

    textarea {
        outline: none;
        border: none;
    }

    textarea:focus,
    input:focus {
        border-color: transparent !important;
    }

    input:focus::-webkit-input-placeholder {
        color: transparent;
    }

    input:focus:-moz-placeholder {
        color: transparent;
    }

    input:focus::-moz-placeholder {
        color: transparent;
    }

    input:focus:-ms-input-placeholder {
        color: transparent;
    }

    textarea:focus::-webkit-input-placeholder {
        color: transparent;
    }

    textarea:focus:-moz-placeholder {
        color: transparent;
    }

    textarea:focus::-moz-placeholder {
        color: transparent;
    }

    textarea:focus:-ms-input-placeholder {
        color: transparent;
    }

    input::-webkit-input-placeholder {
        color: #999999;
    }

    input:-moz-placeholder {
        color: #999999;
    }

    input::-moz-placeholder {
        color: #999999;
    }

    input:-ms-input-placeholder {
        color: #999999;
    }

    textarea::-webkit-input-placeholder {
        color: #999999;
    }

    textarea:-moz-placeholder {
        color: #999999;
    }

    textarea::-moz-placeholder {
        color: #999999;
    }

    textarea:-ms-input-placeholder {
        color: #999999;
    }

    /*---------------------------------------------*/
    button {
        outline: none !important;
        border: none;
        background: transparent;
    }

    button:hover {
        cursor: pointer;
    }

    iframe {
        border: none !important;
    }




    /*//////////////////////////////////////////////////////////////////
[ Contact ]*/

    .container-contact100 {
        width: 100%;
        min-height: 100vh;
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        padding: 15px;
        background: transparent;
        position: relative;
        z-index: 1;
    }

    .contact100-map {
        position: absolute;
        z-index: -2;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
    }

    .wrap-contact100 {
        width: 670px;
        background: #fff;
        border-radius: 10px;
        overflow: hidden;
        position: relative;
    }

    /*==================================================================
[ Title form ]*/


    .contact100-form-title {
        width: 100%;
        position: relative;
        z-index: 1;
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        flex-wrap: wrap;
        flex-direction: column;
        align-items: center;

        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;

        padding: 64px 15px 64px 15px;
    }

    .contact100-form-title-1 {
        font-size: 20px;
        color: #fff;
        line-height: 1.2;
        text-align: center;
        padding-bottom: 7px;
    }

    .contact100-form-title-2 {
        font-size: 15px;
        color: #fff;
        line-height: 1.5;
        text-align: center;
    }


    .contact100-form-title::before {
        content: "";
        display: block;
        position: absolute;
        z-index: -1;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background-color: rgba(54, 84, 99, 0.7);
    }


    /*==================================================================
[ Form ]*/

    .contact100-form {
        width: 100%;
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        padding: 43px 88px 57px 190px;
    }


    /*------------------------------------------------------------------
[ Input ]*/

    .wrap-input100 {
        width: 100%;
        position: relative;
        border-bottom: 1px solid #b2b2b2;
        margin-bottom: 26px;
    }

    .label-input100 {
        font-size: 15px;
        color: #808080;
        line-height: 1.2;
        text-align: right;

        position: absolute;
        top: 14px;
        left: -105px;
        width: 80px;

    }

    /*---------------------------------------------*/
    .input100 {
        font-size: 15px;
        color: #555555;
        line-height: 1.2;

        display: block;
        width: 100%;
        background: transparent;
        padding: 0 5px;
    }

    .focus-input100 {
        position: absolute;
        display: block;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        pointer-events: none;
    }

    .focus-input100::before {
        content: "";
        display: block;
        position: absolute;
        bottom: -1px;
        left: 0;
        width: 0;
        height: 1px;

        -webkit-transition: all 0.6s;
        -o-transition: all 0.6s;
        -moz-transition: all 0.6s;
        transition: all 0.6s;

        background: #57b846;
    }


    /*---------------------------------------------*/
    input.input100 {
        height: 45px;
    }


    textarea.input100 {
        min-height: 115px;
        padding-top: 14px;
        padding-bottom: 13px;
    }


    .input100:focus+.focus-input100::before {
        width: 100%;
    }

    .has-val.input100+.focus-input100::before {
        width: 100%;
    }


    /*------------------------------------------------------------------
[ Button ]*/
    .container-contact100-form-btn {
        width: 100%;
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        flex-wrap: wrap;
        padding-top: 8px;
    }

    .contact100-form-btn {
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 0 20px;
        min-width: 160px;
        height: 50px;
        background-color: #57b846;
        border-radius: 25px;

        font-size: 16px;
        color: #fff;
        line-height: 1.2;

        -webkit-transition: all 0.4s;
        -o-transition: all 0.4s;
        -moz-transition: all 0.4s;
        transition: all 0.4s;
    }

    .contact100-form-btn i {
        -webkit-transition: all 0.4s;
        -o-transition: all 0.4s;
        -moz-transition: all 0.4s;
        transition: all 0.4s;
    }

    .contact100-form-btn:hover {
        background-color: #333333;
    }

    .contact100-form-btn:hover i {
        -webkit-transform: translateX(10px);
        -moz-transform: translateX(10px);
        -ms-transform: translateX(10px);
        -o-transform: translateX(10px);
        transform: translateX(10px);
    }


    /*------------------------------------------------------------------
[ Responsive ]*/

    @media (max-width: 576px) {
        .contact100-form {
            padding: 43px 15px 57px 117px;
        }
    }

    @media (max-width: 480px) {
        .contact100-form {
            padding: 43px 15px 57px 15px;
        }

        .label-input100 {
            text-align: left;
            position: unset;
            top: unset;
            left: unset;
            width: 100%;
            padding: 0 5px;
        }
    }

    select.input100{
        border: 0;
        padding: 15px 0;
    }

    @media (max-width: 992px) {
        .alert-validate::before {
            visibility: visible;
            opacity: 1;
        }
    }

    .bg-contatc{
        background-image: url('<?php echo $url?>src/images/bg-contato.jpg');
        background-size: cover;
        background-position: center;
    }
</style>

<section id="contato">
<div class="container-contact100 bg-contatc">
    <div class="contact100-map" id="google_map" data-map-x="40.722047" data-map-y="-73.986422" data-pin="images/icons/map-marker.png" data-scrollwhell="0" data-draggable="1">

    </div>
    <div class="wrap-contact100">
        <div class="contact100-form-title" style="background:#000">
            <span class="contact100-form-title-2">Qual a sua dúvida?</span>
        </div>
        <form class="contact100-form validate-form">
            <div class="wrap-input100 validate-input">
                <span class="label-input100">Unidade</span>
                <select name="subject" id="subject" class="input100">
                    <option value="" disabled selected>Selecione</option>
                    <option value="Pinda">Pinda</option>
                    <option value="Taubaté">Taubaté</option> 
                    <option value="Campos do Jordão">Campos do Jordão</option> 
                </select>
            </div>
            <div class="wrap-input100 validate-input" >
                <span class="label-input100">Nome</span>
                <input class="input100" type="text" name="name" placeholder="">
            </div>
            <div class="wrap-input100 validate-input">
                <span class="label-input100">E-mail</span>
                <input class="input100" type="text" name="email" placeholder="">
            </div>
            <div class="wrap-input100 validate-input">
                <span class="label-input100">Celular</span>
                <input class="input100" type="text" name="phone" placeholder="">
            </div>
            <div class="wrap-input100 validate-input">
                <span class="label-input100">Assunto</span>
                <select name="subject" id="subject" class="input100">
                    <option value="" disabled selected>Selecione</option>
                    <option value="Duvida">Duvida</option>
                    <option value="Reclamação">Reclamação</option>
                    <option value="Orçamento">Orçamento</option> 
                </select>
            </div>
            <div class="wrap-input100 validate-input">
                <span class="label-input100">Mensagem</span> 
                <textarea class="input100" name="message" placeholder=""></textarea>
            </div>
            <div class="container-contact100-form-btn">
                <button class="contact100-form-btn">Enviar</button>
            </div>
        </form>
    </div>
</div>
</section>